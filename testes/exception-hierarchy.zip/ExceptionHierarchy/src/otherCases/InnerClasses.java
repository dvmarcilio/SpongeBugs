package otherCases;

import exceptions.checked.a.MException;

public class InnerClasses {

	public static class TestService {

	}

	public static class ExtendedTestService extends TestService {

	}

	public static class TestService2 {

	}

	public static interface TestServiceLocator {

		TestService getTestService();
	}

	public static interface TestServiceLocator2 {

		TestService getTestService(String id) throws CustomServiceLocatorException2;
	}

	public static interface TestServiceLocator3 {

		TestService getTestService();

		TestService getTestService(String id);

		TestService getTestService(int id);

		TestService someFactoryMethod();
	}

	public static interface TestService2Locator {

		TestService2 getTestService() throws CustomServiceLocatorException3;
	}

	public static interface ServiceLocatorInterfaceWithExtraNonCompliantMethod {

		TestService2 getTestService();

		TestService2 getTestService(String serviceName, String defaultNotAllowedParameter);
	}

	@SuppressWarnings("serial")
	public static class CustomServiceLocatorException1 extends RuntimeException {

		public CustomServiceLocatorException1(String message, Throwable cause) {
			super(message, cause);
		}
	}

	@SuppressWarnings("serial")
	public static class CustomServiceLocatorException2 extends Exception {

		public CustomServiceLocatorException2(Throwable cause) {
			super("", cause);
		}
	}

	@SuppressWarnings("serial")
	public static class CustomServiceLocatorException3 extends Exception {

		public CustomServiceLocatorException3(String message) {
			super();
		}
	}

	@SuppressWarnings("serial")
	public static class ExceptionClassWithOnlyZeroArgCtor extends Exception {

	}

	@SuppressWarnings("serial")
	public static class DeepNestedStaticException extends MException {

	}

}

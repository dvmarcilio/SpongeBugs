package otherCases;

public abstract class AbstractCheckedException extends Exception {

}

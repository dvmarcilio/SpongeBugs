package exceptions.checked.b;

public class FException extends BException {

}

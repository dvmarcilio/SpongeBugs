package exceptions.checked.b;

public class HException extends FException {

}

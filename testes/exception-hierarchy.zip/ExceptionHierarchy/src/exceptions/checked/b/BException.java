package exceptions.checked.b;

public class BException extends Exception {

}

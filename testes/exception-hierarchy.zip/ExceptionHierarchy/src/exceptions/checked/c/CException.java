package exceptions.checked.c;

public class CException extends Exception {

}

package exceptions.checked.c;

public class IException extends CException {

}

package exceptions.checked;

public class ZException extends Exception {

}

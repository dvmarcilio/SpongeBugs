package exceptions.checked.a;

public class JException extends DException {

}

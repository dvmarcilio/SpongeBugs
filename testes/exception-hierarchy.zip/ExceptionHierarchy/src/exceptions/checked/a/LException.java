package exceptions.checked.a;

public class LException extends DException {

}

package exceptions.checked.a;

public class KException extends JException {

}

package exceptions.checked.a;

public class EException extends DException {

}

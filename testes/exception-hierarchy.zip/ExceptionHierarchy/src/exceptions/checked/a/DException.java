package exceptions.checked.a;

public class DException extends AException {

}

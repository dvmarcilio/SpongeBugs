package exceptions.checked.a;

public class MException extends GException {

}

package exceptions.checked.a;

public class NException extends LException {

}

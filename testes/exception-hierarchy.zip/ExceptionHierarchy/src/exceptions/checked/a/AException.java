package exceptions.checked.a;

public class AException extends Exception {

}

package exceptions.checked.a;

public class GException extends EException {

}

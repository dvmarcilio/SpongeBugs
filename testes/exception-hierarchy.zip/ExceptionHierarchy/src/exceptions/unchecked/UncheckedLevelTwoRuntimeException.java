package exceptions.unchecked;

public class UncheckedLevelTwoRuntimeException extends RuntimeException {
	
	
	
}

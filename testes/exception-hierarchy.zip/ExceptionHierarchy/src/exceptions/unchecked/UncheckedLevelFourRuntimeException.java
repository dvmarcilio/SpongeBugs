package exceptions.unchecked;

public class UncheckedLevelFourRuntimeException extends UncheckedLevelThreeRuntimeException {

}

package exceptions.unchecked;

public class UncheckedLevelThreeRuntimeException extends UncheckedLevelTwoRuntimeException {

}
